#ifndef __EEPROM_H
#define __EEPROM_H

void EEPROMWrite(unsigned char, unsigned char);
unsigned char EEPROMRead(unsigned char);

#endif