#ifndef __delay_H
#define __delay_H

void delay(unsigned int);

#endif