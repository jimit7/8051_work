#ifndef __INCLUDES_H
#define __INCLUDES_H

#include<reg51.h>
#include "delay.h"
#include "I2C.h"
#include "LCD.h"
#include "keypad.h"
#include "EEPROM.h"


#endif